import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createChart, CandlestickSeries, HistogramSeries, ColorType } from 'lightweight-charts';
import { Activity, BarChart3, Bell, Bot, BriefcaseBusiness, CandlestickChart, ChevronDown, CircleHelp, Clock3, Coins, Crosshair, Gauge, LayoutDashboard, LineChart, ListFilter, Menu, Search, Settings, ShieldCheck, SlidersHorizontal, Sparkles, Star, TrendingDown, TrendingUp, Wallet, X } from 'lucide-react';

const markets = ['Stocks', 'F&O', 'Crypto', 'Commodities'];
const watchlists = {
  Stocks: [{s:'NIFTY 50',n:'NSE Index',p:'—',c:'—'},{s:'RELIANCE',n:'Reliance Industries',p:'—',c:'—'},{s:'HDFCBANK',n:'HDFC Bank',p:'—',c:'—'},{s:'TCS',n:'Tata Consultancy',p:'—',c:'—'},{s:'INFY',n:'Infosys',p:'—',c:'—'}],
  'F&O': [{s:'NIFTY',n:'Index Futures',p:'—',c:'—'},{s:'BANKNIFTY',n:'Index Futures',p:'—',c:'—'},{s:'FINNIFTY',n:'Index Futures',p:'—',c:'—'},{s:'SENSEX',n:'Index Derivatives',p:'—',c:'—'}],
  Crypto: [{s:'BTCUSDT',n:'Bitcoin / USDT',p:'—',c:'—'},{s:'ETHUSDT',n:'Ethereum / USDT',p:'—',c:'—'},{s:'SOLUSDT',n:'Solana / USDT',p:'—',c:'—'},{s:'BNBUSDT',n:'BNB / USDT',p:'—',c:'—'}],
  Commodities: [{s:'XAUUSD',n:'Gold / US Dollar',p:'—',c:'—'},{s:'XAGUSD',n:'Silver / US Dollar',p:'—',c:'—'}]
};
const nav = [{label:'Overview',icon:LayoutDashboard},{label:'Markets',icon:BarChart3},{label:'AI Analysis',icon:Bot},{label:'Open Trades',icon:BriefcaseBusiness},{label:'Trade History',icon:Clock3},{label:'Portfolio',icon:Wallet},{label:'Performance',icon:Gauge}];

function Logo(){return <div className="brand"><div className="brand-mark"><svg viewBox="0 0 44 44" aria-hidden="true"><path d="M22 3 39 13v18L22 41 5 31V13z" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="M13 28V16l9 8 9-8v12M15 12h14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/><circle cx="22" cy="8" r="2" fill="#e9bd70"/></svg></div><div><b>KRISHNA</b><span>AI BOT <i>TERMINAL</i></span></div></div>}

function ChartPanel({symbol,interval}){
 const host=useRef(null); const chartRef=useRef(null);
 useEffect(()=>{
  if(!host.current)return;
  const chart=createChart(host.current,{autoSize:true,layout:{background:{type:ColorType.Solid,color:'#0b111d'},textColor:'#8491a7',fontFamily:'Inter,system-ui,sans-serif',fontSize:11},grid:{vertLines:{color:'#172131'},horzLines:{color:'#172131'}},rightPriceScale:{borderColor:'#263246'},timeScale:{borderColor:'#263246',timeVisible:true,secondsVisible:false},crosshair:{vertLine:{color:'#68758b',labelBackgroundColor:'#263246'},horzLine:{color:'#68758b',labelBackgroundColor:'#263246'}}});
  chartRef.current=chart;
  const candle=chart.addSeries(CandlestickSeries,{upColor:'#28c89a',downColor:'#f06c78',borderUpColor:'#28c89a',borderDownColor:'#f06c78',wickUpColor:'#28c89a',wickDownColor:'#f06c78',lastValueVisible:false,priceLineVisible:false});
  const vol=chart.addSeries(HistogramSeries,{priceFormat:{type:'volume'},priceScaleId:'',lastValueVisible:false,priceLineVisible:false});
  vol.priceScale().applyOptions({scaleMargins:{top:.84,bottom:0}});
  // No synthetic candles are rendered. A real feed can populate this series through the adapter.
  candle.setData([]); vol.setData([]);
  const ro=new ResizeObserver(()=>chart.applyOptions({width:host.current?.clientWidth||600,height:host.current?.clientHeight||390})); ro.observe(host.current);
  return()=>{ro.disconnect();chart.remove();chartRef.current=null;};
 },[symbol,interval]);
 return <div className="chart-wrap"><div ref={host} className="chart-canvas"/><div className="chart-empty"><div className="empty-icon"><CandlestickChart size={22}/></div><b>Waiting for market data</b><span>Connect a supported data feed to display verified live candles for {symbol}.</span><small>LIVE DATA NOT CONNECTED · NO DEMO PRICES</small></div></div>
}

function App(){
 const [market,setMarket]=useState('Stocks'); const [symbol,setSymbol]=useState('NIFTY 50'); const [interval,setInterval]=useState('5m'); const [active,setActive]=useState('Overview'); const [search,setSearch]=useState(''); const [mobileOpen,setMobileOpen]=useState(false); const [rightOpen,setRightOpen]=useState(true); const [watch,setWatch]=useState(true);
 const items=useMemo(()=>watchlists[market].filter(x=>(x.s+' '+x.n).toLowerCase().includes(search.toLowerCase())),[market,search]);
 useEffect(()=>{if(!watchlists[market].some(x=>x.s===symbol))setSymbol(watchlists[market][0].s)},[market]);
 const changeMarket=m=>{setMarket(m);setSearch('')};
 return <div className="app-shell">
  <aside className={`sidebar ${mobileOpen?'mobile-open':''}`}>
   <div className="side-top"><Logo/><button className="icon-btn mobile-close" onClick={()=>setMobileOpen(false)}><X size={18}/></button></div>
   <div className="profile-chip"><div className="avatar">K</div><div><b>KRISHNA AI</b><span>Trading workspace</span></div><span className="online-dot"/></div>
   <div className="side-label">WORKSPACE</div>
   <nav>{nav.map(({label,icon:Icon})=><button key={label} className={`nav-item ${active===label?'selected':''}`} onClick={()=>{setActive(label);setMobileOpen(false)}}><Icon size={17}/><span>{label}</span>{label==='Open Trades'&&<em>0</em>}</button>)}</nav>
   <div className="side-label market-label">MARKETS</div>
   <div className="market-nav">{markets.map(m=><button key={m} onClick={()=>{changeMarket(m);setActive('Markets');setMobileOpen(false)}} className={market===m?'market-active':''}><span className="market-bullet"/>{m}</button>)}</div>
   <div className="sidebar-bottom"><div className="connection-card"><div className="connection-head"><span className="status-dot"/> DATA CONNECTION</div><b>Not connected</b><small>Live market feed unavailable</small></div><button className="nav-item" onClick={()=>setActive('Settings')}><Settings size={17}/><span>Settings</span></button><button className="nav-item"><CircleHelp size={17}/><span>Help & support</span></button><div className="version">KRISHNA AI BOT <span>v1.0.0</span></div></div>
  </aside>
  {mobileOpen&&<div className="scrim" onClick={()=>setMobileOpen(false)}/>}
  <main className="main-area">
   <header className="topbar"><div className="top-left"><button className="icon-btn menu-btn" onClick={()=>setMobileOpen(true)}><Menu size={19}/></button><div className="breadcrumb">Workspace <span>/</span> <b>{active}</b></div></div><div className="top-actions"><div className="market-status"><span className="status-dot"/> Market data disconnected</div><button className="icon-btn" aria-label="Notifications"><Bell size={18}/></button><div className="user-avatar">K</div></div></header>
   <div className="content-area">
    <div className="page-heading"><div><div className="eyebrow">TRADING WORKSPACE <span>•</span> INDIA</div><h1>{active==='Overview'?'Market overview':active}</h1><p>Clear market context. Disciplined decisions. No fabricated data.</p></div><div className="heading-actions"><button className="outline-btn" onClick={()=>setRightOpen(!rightOpen)}><SlidersHorizontal size={15}/> Panels</button><button className="gold-btn" onClick={()=>setActive('AI Analysis')}><Sparkles size={15}/> AI analysis</button></div></div>
    <div className="notice"><ShieldCheck size={16}/><span><b>Paper / live status: not configured.</b> No broker, exchange or market-data connection is active. Prices, signals and P&amp;L are intentionally not simulated.</span></div>
    <section className="stats-grid"><Stat icon={Wallet} label="Account balance" value="—" note="Connect broker account"/><Stat icon={Activity} label="Today's P&L" value="—" note="No verified executions"/><Stat icon={BriefcaseBusiness} label="Open positions" value="0" note="No trade records loaded"/><Stat icon={Gauge} label="Win rate" value="—" note="Needs verified trade history"/></section>
    <div className={`workspace-grid ${rightOpen?'':'right-hidden'}`}>
     <section className="center-column">
      <div className="panel chart-panel"><div className="panel-head chart-head"><div className="instrument"><div className="instrument-icon"><CandlestickChart size={18}/></div><div><div className="symbol-line"><b>{symbol}</b><span className="exchange-tag">{market==='Stocks'||market==='F&O'?'NSE / BSE':'MARKET'}</span></div><small>{watchlists[market].find(x=>x.s===symbol)?.n||'Selected instrument'}</small></div></div><div className="chart-tools"><button className="tool-btn"><Star size={15}/></button><button className="tool-btn"><Search size={15}/></button><button className="tool-btn"><ListFilter size={15}/></button></div></div>
       <div className="price-strip"><div><span>LAST PRICE</span><b>—</b></div><div><span>CHANGE</span><b className="muted-value">—</b></div><div><span>DAY HIGH</span><b>—</b></div><div><span>DAY LOW</span><b>—</b></div><div><span>VOLUME</span><b>—</b></div></div>
       <div className="timeframe-row"><div className="timeframes">{['1m','3m','5m','15m','30m','1H','4H','1D','1W','1M'].map(t=><button key={t} className={interval===t?'tf-active':''} onClick={()=>setInterval(t)}>{t}</button>)}</div><button className="chart-type"><LineChart size={15}/> Indicators <ChevronDown size={13}/></button></div>
       <ChartPanel symbol={symbol} interval={interval}/>
       <div className="chart-footer"><span><span className="legend-dot"/> Candles</span><span><span className="legend-dot volume-dot"/> Volume</span><span className="footer-right">Chart engine · Lightweight Charts</span></div>
      </div>
      <div className="panel lower-panel"><div className="tabs"><button className="tab-active">Trade panel</button><button>Order book</button><button>Alerts</button><button>Strategy tester</button></div><div className="empty-row"><div className="empty-icon small"><BriefcaseBusiness size={17}/></div><div><b>No trade activity yet</b><span>Verified orders and positions will appear here after a connection is configured.</span></div></div></div>
     </section>
     {rightOpen&&<aside className="right-column"><div className="panel watch-panel"><div className="panel-head"><div><h3>Watchlist</h3><small>Track selected instruments</small></div><button className="tool-btn"><SlidersHorizontal size={15}/></button></div><div className="market-tabs">{markets.map(m=><button key={m} onClick={()=>changeMarket(m)} className={market===m?'market-tab-active':''}>{m==='Commodities'?'Commod.':m}</button>)}</div><div className="search-box"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search symbol"/></div><div className="watch-columns"><span>INSTRUMENT</span><span>PRICE</span><span>CHANGE</span></div><div className="watch-items">{items.map(it=><button key={it.s} className={`watch-item ${symbol===it.s?'watch-selected':''}`} onClick={()=>setSymbol(it.s)}><div className="coin-icon">{it.s.slice(0,1)}</div><div className="watch-name"><b>{it.s}</b><small>{it.n}</small></div><span className="watch-price">—</span><span className="watch-change">—</span></button>)}{items.length===0&&<div className="no-results">No matching symbols</div>}</div><button className="add-symbol" onClick={()=>setSearch('')}>+ Browse available symbols</button></div>
      <div className="panel ai-panel"><div className="ai-title"><div className="ai-icon"><Sparkles size={16}/></div><div><h3>Krishna AI insight</h3><small>Market analysis assistant</small></div><span className="beta">BETA</span></div><div className="ai-empty"><Bot size={24}/><b>Awaiting verified market data</b><p>AI analysis will be available when a real market feed is connected. No BUY / SELL signal is generated without data.</p></div><button className="ai-action" onClick={()=>setActive('AI Analysis')}>Open AI analysis <span>→</span></button></div>
      <div className="risk-note"><ShieldCheck size={16}/><div><b>Risk rules configured as goals</b><span>Minimum planned R:R 1:3 · Never widen SL · No automatic 1:2 exit. Execution enforcement still needs testing.</span></div></div>
     </aside>}
    </div>
    <footer className="page-footer"><span>© KRISHNA AI BOT</span><span>Built for disciplined trading <i>•</i> Data integrity first</span></footer>
   </div>
  </main>
 </div>
}
function Stat({icon:Icon,label,value,note}){return <div className="panel stat-card"><div className="stat-top"><span>{label}</span><Icon size={16}/></div><b className="stat-value">{value}</b><small>{note}</small></div>}

export default App;
