# KRISHNA AI BOT — React + Vite starter

A responsive dark trading-terminal UI for Android and desktop.

## Run locally

1. Install Node.js (LTS) on a computer.
2. Extract this folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite.

## Free GitHub + Cloudflare Pages deployment

- Push the project files to the existing `krishna-ai-bot` GitHub repository.
- In Cloudflare Pages, connect that repository.
- Framework preset: **Vite**
- Build command: `npm run build`
- Build output directory: `dist`
- No paid plan is required for this frontend deployment on the free tier, subject to provider limits and current terms.

## Important data and trading notes

- This starter intentionally displays no fabricated prices, candles, signals, account balances, or P&L.
- The chart uses TradingView Lightweight Charts, but it stays empty until a real, authorized market-data adapter supplies candles.
- No broker is connected; this UI does not place orders and is not a running trading bot.
- Never put broker API secrets in frontend code or `VITE_*` variables. A secure server-side backend is required for authenticated feeds and order execution.
- Current UI scope: Indian stocks and F&O, crypto, gold and silver. Forex is not included yet, matching the agreed first phase.
- Risk rules shown in the interface are goals only; they are not enforced by an execution engine yet. Validate backtests and paper trading before any live use.

## Project structure

- `index.html` — Vite entry
- `src/main.jsx` — React bootstrap
- `src/App.jsx` — dashboard and chart panel
- `src/styles.css` — responsive dark UI
